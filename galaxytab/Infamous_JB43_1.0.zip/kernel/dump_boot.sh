#!/tmp/busybox sh
/tmp/busybox sh -c "/tmp/busybox dd if=/dev/block/mmcblk0p3 of=/tmp/boot.img"
