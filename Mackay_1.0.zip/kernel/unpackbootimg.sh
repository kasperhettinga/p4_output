#!/sbin/sh
/tmp/unpackbootimg -i /tmp/boot.img -o /tmp/
